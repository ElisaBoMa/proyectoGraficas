Integrantes:
Elisa Bobadilla Martínez - A01733203
Luis Alberto Aguilar González - A01329926
Arturo Montes de Oca Barrios - A01732697

Descripción Proyecto:
El proyecto consistirá de una recreación de la siguiente escena de
la serie de televisión iCarly:
https://youtu.be/TG0vk6EHCRU

Específicamente, se recreará una escena en el planeta Marte
con los personajes que aparecen en el video. Al centro de la escena
se mostrará un hamster en traje espacial y un alien. A lo largo
de la escena se recreará un burrito entre los dos personajes.
Alrededor de los personajes se mostrará un terreno representativo
del planeta Marte. Pensábamos agregar objetos moviéndose en el fondo,
como un astromóvil explorando el terreno u otra nave alien 
moviéndose. En el "skybox", se mostrará el espacio con el planeta
Tierra y el espacio trasladándose a través del skybox
